package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


import main.Lab1;

class test {

Lab1 mytest = new Lab1();
	
	int[] arr = {5,5,5};	
	
	int n = arr.length;
	
	
	
	
	@Test
	void testmean() {
		assertEquals(5.0 , mytest.MyMean(arr,n));
	}
	
	@Test
	void testmedian() {
		assertEquals(5.0 , mytest.MyMedian(arr,n));
	}
	
	@Test
	void testmode() {
		assertEquals(5.0 , mytest.MyMode(arr,n));
	}

}
