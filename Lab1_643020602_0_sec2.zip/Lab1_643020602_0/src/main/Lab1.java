package main;

import java.util.Arrays;

public class Lab1 {

public float MyMean(int[] arr , int n) {
		
		int sum = 0;
		for(int i = 0 ; i < n ; i++) {
			
			sum  += arr[i];
			
		}
		float v = sum / n;
		
		return v;
	}
	
	public float MyMedian(int[] arr , int n) {
		
		Arrays.sort(arr);
		float m = 0;
		
		if (n % 2 == 1) {
			m = arr[(n+1)/2-1];
		}
		else {
			m = (arr[n/2-1]+ arr[n/2])/2;
		}
		
		return m;
	}
	
	public int MyMode(int[] arr , int n) {
		
		int maxV = 0;
		int maxC = 0;
		int count;
		for(int i = 0 ; i < n ; i++) {
			 count = 0;
			 for(int j = 0 ; j < n ; j++) {
					if(arr[i] == arr[j]) {
						count++;
					}
				}
			 if(count > maxC) {
				 maxC = count;
				 maxV = arr[i];
			 }
		}
		
		
		return maxV;
	}
}